import { Component, HostBinding, OnDestroy } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { LeaveService } from '../../../services/leave-service/leave.service';
import { DatePipe } from "@angular/common";
import { UserService } from '../../../services/user-service/user.service';
import { ExcelService } from '../../../services/excel.service';

@Component({
  selector: 'ngx-team-report',
  templateUrl: './team-report.component.html',
  styleUrls: ['./team-report.component.scss']
})
export class TeamReportComponent {

  MONTHS = [
    {
      id: 0,
      name: "January"
    },
    {
      id: 1,
      name: "February"
    },
    {
      id: 2,
      name: "March"
    },
    {
      id: 3,
      name: "April"
    },
    {
      id: 4,
      name: "May"
    },
    {
      id: 5,
      name: "June"
    },
    {
      id: 6,
      name: "July"
    },
    {
      id: 7,
      name: "August"
    },
    {
      id: 8,
      name: "September"
    },
    {
      id: 9,
      name: "October"
    },
    {
      id: 10,
      name: "November"
    },
    {
      id: 11,
      name: "December"
    },
  ]

  CURRENT_YEAR = new Date().getFullYear();

  YEARS = Array.from(new Array(3), (x, i) => this.CURRENT_YEAR - i);

  asOfDate: any;
  loading = false;
  user: any;

  empUnderManager: any;
  selectedEmp;

  source: LocalDataSource = new LocalDataSource();
  sourceAsData: any;

  settings = {
    hideSubHeader: true,
    pager: {
      perPage: 10
    },
    actions: {
      add: false,
      edit: false,
      delete: false,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    columns: {
      EmpId: {
        title: 'Employee ID',
        type: 'number',
        filter: false
      },
      Name: {
        title: 'Name',
        type: 'string',
        filter: false
      },
      Total_Hours: {
        title: 'Total Hours Spent',
        type: 'string',
        filter: false
      }
    }
  };

  selectedEmpForComp;
  selectedMonth: any;
  selectedYear: any;
  loadingComp = false;
  showTable: boolean = false;

  sourceForComp: LocalDataSource = new LocalDataSource();
  sourceAsDataForComp: any;

  settingsForComp: any;

  constructor(
    private authService: NbAuthService,
    private leaveService: LeaveService,
    private userService: UserService,
    private datePipe: DatePipe,
    private excelService: ExcelService
  ) {

    this.authService.onTokenChange()
      .subscribe((token: NbAuthJWTToken) => {
        if (token.isValid()) {
          this.user = token.getPayload();
        }
      });

    this.userService.getTeamUsers(this.user.companyCode, this.user.empid)
      .subscribe((response) => {
        this.empUnderManager = response
      });

  }

  load() {
    this.loading = true
    var empids = this.selectedEmp.map(item => item.empId);

    this.leaveService.getManagerReportData(this.user.companyCode, empids, this.datePipe.transform(this.asOfDate.start, "yyyyMMdd"),
      this.datePipe.transform(this.asOfDate.end, "yyyyMMdd"))
      .subscribe((response) => {
        this.loading = false
        this.source.load(response);
        this.sourceAsData = response
      },
        (error) => {
          this.source = new LocalDataSource();
          this.loading = false;
          console.log(error)
        });
  }

  isEnabled() {
    return typeof this.asOfDate !== "undefined" && typeof this.selectedEmp !== "undefined" && this.asOfDate !== "";
  }

  export() {
    var headers = ["Start Date", " End Date", "Total Hours"]
    var startDate = this.datePipe.transform(this.asOfDate.start, "yyyyMMdd")
    var endDate = this.datePipe.transform(this.asOfDate.end, "yyyyMMdd")
    this.excelService.exportAsExcelFile(this.sourceAsData, headers, "ComprehensiveManagerReport_" + this.user.empid,
      startDate + "_" + endDate);
  }

  isExportEnabled() {
    return typeof this.sourceAsData !== "undefined";
  }

  loadComp() {
    this.loadingComp = true
    var empids = this.selectedEmpForComp.map(item => item.empId);

    var startDate = this.datePipe.transform(new Date(this.selectedYear, this.selectedMonth.id, 1), "yyyyMMdd");
    var endDate = this.datePipe.transform(new Date(this.selectedYear, this.selectedMonth.id + 1, 0), "yyyyMMdd");

    this.leaveService.getManagerCompReportData(this.user.companyCode, empids, startDate, endDate)
      .subscribe((response) => {
        this.showTable = true;
        this.loadingComp = false;
        this.prepareColumns(response);
      },
        (error) => {
          this.sourceForComp = new LocalDataSource();
          this.loadingComp = false;
          this.showTable = false;
          console.log(error)
        });
  }

  isEnabledComp() {
    return typeof this.selectedEmpForComp !== "undefined" && typeof this.selectedMonth !== "undefined" && typeof this.selectedYear !== "undefined";
  }

  exportComp() {
    var headers = []
    for(var key in this.settingsForComp.columns){
      if(key === "empid"){
        headers.push("Employee ID")
      } else if (key === "name"){
        headers.push("Name")
      } else{
        headers.push(key.substring(6));
      }   
    }

    this.excelService.exportAsExcelFile(this.sourceAsDataForComp, headers, "ComprehensiveManagerReport_" + this.user.empid,
      this.selectedMonth.name);
  }

  isCompExportEnabled() {
    return typeof this.sourceAsDataForComp !== "undefined";
  }

  prepareColumns(dataObj: any) {

    var newSettings = {
      hideSubHeader: true,
      pager: {
        perPage: 10
      },
      actions: {
        add: false,
        edit: false,
        delete: false,
      },
      columns: {
      }
    }

    newSettings.columns['empid'] = {
      title: 'Employee ID',
      type: 'string',
      filter: false
    }

    newSettings.columns['name'] = {
      title: 'Name',
      type: 'string',
      filter: false
    }

    if (typeof dataObj[0].data !== "undefined" && dataObj[0].data !== []) {
      for (var entry of dataObj[0].data) {
        newSettings.columns[`ZDate_${entry.date}`] = {
          title: entry.date,
          type: 'string',
          filter: false
        }
      }
    }

    this.settingsForComp = Object.assign({}, newSettings);

    console.log(this.settingsForComp);

    var dataTobeDisplayed = [];
    for (var emp of dataObj) {
      var entryToPush = {
        empid: emp.empid,
        name: emp.name,
      }
      for (var entry of emp.data) {
        entryToPush[`ZDate_${entry.date}`] = entry.hours
      }
      dataTobeDisplayed.push(entryToPush);
    }

    this.sourceForComp.load(dataTobeDisplayed);

    this.sourceAsDataForComp = dataTobeDisplayed;
  }



}
