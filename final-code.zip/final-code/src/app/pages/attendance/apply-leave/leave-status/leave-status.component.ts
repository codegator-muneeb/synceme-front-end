import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { LeaveService } from '../../../../services/leave-service/leave.service';
import { leaveRequest } from '../../../../services/leave-service/leave-service.adapters';
import { NbGlobalPhysicalPosition, NbToastrService } from '@nebular/theme';
import { NbToastStatus } from '@nebular/theme/components/toastr/model';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-leave-status',
  templateUrl: './leave-status.component.html',
  styleUrls: ['./leave-status.component.scss']
})
export class LeaveStatusComponent {

  settings = {
    hideSubHeader: true,
    pager: {
      perPage: 6
    },
    actions: {
      add: false,
      edit: false,
      delete: false,
    },
    columns: {
      id: {
        title: 'Leave ID',
        type: 'number',
        filter: true
      },
      type: {
        title: 'Type of Leave',
        type: 'string',
        filter: true
      },
      from: {
        title: 'From',
        type: 'string',
        filter: true
      },
      to: {
        title: 'To',
        type: 'string',
        filter: true
      },
      status: {
        title: 'Status',
        type: 'string',
        filter: true
      },
      days: {
        title: 'Days Used',
        type: 'string',
        filter: true
      },
      modified_by: {
        title: 'Modified By',
        type: 'string',
        filter: true
      }
    },
  };

  source: LocalDataSource = new LocalDataSource();
  sourceForHistory: LocalDataSource = new LocalDataSource();
  user: any;
  selectedLeave: leaveRequest;

  constructor(private authService: NbAuthService,
    private leaveService: LeaveService,
    private toastrService: NbToastrService,
    private router: Router) {

    this.authService.onTokenChange()
      .subscribe((token: NbAuthJWTToken) => {
        if (token.isValid()) {
          this.user = token.getPayload();
        }
      });

    this.leaveService.getLeaveRequests(this.user.companyCode, this.user.empid)
      .subscribe((response) => {
        console.log(response)
        const dataForPending = response.filter(leave => leave.status === "Pending");
        const dataForHistory = response.filter(leave => leave.status !== "Pending");
        this.source.load(dataForPending);
        this.sourceForHistory.load(dataForHistory);
      },
        (error) => {
          console.log(error);
          this.source = new LocalDataSource();
          this.sourceForHistory = new LocalDataSource();
        });

  }

  private showToast(type: NbToastStatus, title: string, body: string) {
    const config = {
      status: type,
      destroyByClick: true,
      duration: 2000,
      hasIcon: true,
      position: NbGlobalPhysicalPosition.TOP_RIGHT,
      preventDuplicates: false,
    };
    const titleContent = title ? title : '';

    this.toastrService.show(
      body,
      titleContent,
      config);
  }

  isCancelEnabled() {
    return typeof this.selectedLeave !== "undefined";
  }

  cancelLeave() {
    if (window.confirm(`Are you sure, you want to cancel leave id: ${this.selectedLeave.id}?`)) {
      this.leaveService.rejectRequest(this.user.companyCode, this.user.empid, this.selectedLeave.id, this.selectedLeave.typeid, Number(this.selectedLeave.days), this.user.empid)
        .subscribe(response => {
          var email = this.selectedLeave.email;
          var subject = `Update on leave request: ${this.selectedLeave.id}`
          var body = `Hi,<br><br>
                      The leave request with id ${this.selectedLeave.id} has been cancelled by the user.
                      <br><br>
                      Regards,<br>
                      Synceme Team.`;
          console.log(body);
          this.leaveService.sendEmail(email, subject, body).subscribe(emailRes => {
            this.showToast(NbToastStatus.SUCCESS, "Success", "Request Cancelled Successfully");
            this.refresh();
          },
            emailErr => {
              this.showToast(NbToastStatus.SUCCESS, "Success", "Request Cancelled Successfully, no mail sent");
              this.refresh();
        })
        }, error => {
      this.showToast(NbToastStatus.WARNING, "Failure", "Error Occurred");
      this.refresh();
    });
  }
}

onRowSelect(row) {
  this.selectedLeave = row.data;
  console.log(this.selectedLeave);
}

refresh() {
  setTimeout(() => {
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
      this.router.navigate(["/pages/attendance/apply-leave"]));
  }, 2000);
}

}
