import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.scss']
})

export class ApplyLeaveComponent{
}
