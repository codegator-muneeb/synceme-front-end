import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LeaveService } from '../../../../services/leave-service/leave.service';
import { officialEntity, user } from '../../../../services/user-service/user-service.adapters';
import { NbAuthJWTToken, NbAuthService } from '@nebular/auth';
import { UserService } from '../../../../services/user-service/user.service';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'ngx-progress-bar',
  templateUrl: 'progress-bar.component.html',
  styleUrls: ['progress-bar.component.scss'],
  providers: [DatePipe]
})
export class ProgressBarComponent implements OnInit {

  @ViewChild("managerOpList") mangerList: any;
  @ViewChild("typeOpList") typeList: any;
  @ViewChild("startTimeList") startTimeList: any;
  @ViewChild("endTimeList") endTimeList: any;
  @ViewChild("stepper") stepper: any;


  typesOfLeaves: officialEntity[];
  managerList: user[];
  days: any;
  status = "Successfully submitted details"

  startTimeQuantifiers = [
    {
      text: "Full Day (00:00:01 Hours)",
      id: 1
    },
    {
      text: "Half Day (12:00:00 Hours)",
      id: 2
    }
  ]

  endTimeQuantifiers = [
    {
      text: "Full Day (23:59:59 Hours)",
      id: 1
    },
    {
      text: "Half Day (12:00:00 Hours)",
      id: 2
    },
  ]

  requestForm: FormGroup;
  user: any;

  constructor(private fb: FormBuilder,
    private leaveService: LeaveService,
    private authService: NbAuthService,
    private userService: UserService,
    private datePipe: DatePipe,
    private router: Router) {

    this.authService.onTokenChange()
      .subscribe((token: NbAuthJWTToken) => {
        if (token.isValid()) {
          this.user = token.getPayload();
        }
      });

    this.leaveService.getLeaveTypes(this.user.companyCode).subscribe(response => {
      console.log(response);
      this.typesOfLeaves = response;
    },
      error => console.log(error));

    this.userService.getEmployeeManagers(this.user.companyCode, this.user.empid).subscribe(response => {
      this.managerList = response;
      console.log(response);
    },
      error => console.log(error))

  }

  ngOnInit() {
    this.requestForm = this.fb.group({
      type: ['', Validators.required],
      manager: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', Validators.required],
    });

    console.log(this.requestForm.invalid);
  }

  submit() {
    var startDate = this.datePipe.transform(this.requestForm.get('startDate').value, "yyyy-MM-dd");
    console.log(startDate);
    if (this.requestForm.get('startTime').value.id === 1) {
      startDate = `${startDate} 00:00:00+00`
    } else {
      startDate = `${startDate} 12:00:00+00`
    }

    var endDate = this.datePipe.transform(this.requestForm.get('endDate').value, "yyyy-MM-dd");

    if (this.requestForm.get('endTime').value.id === 1) {
      endDate = `${endDate} 23:59:59+00`
    } else {
      endDate = `${endDate} 12:00:00+00`
    }

    var days = (new Date(endDate).getTime() - new Date(startDate).getTime()) / (3600 * 1000 * 24);
    days = Math.ceil(days) - days === 0.5 ? days : (Math.ceil(days) - days > 0.5 ? Math.ceil(days) - 0.5 : Math.ceil(days));
    this.days = days;

    const payload = {
      "companyCode": this.user.companyCode,
      "empid": this.user.empid,
      "type": this.requestForm.get('type').value.id,
      "startDate": startDate,
      "endDate": endDate,
      "managerids": this.requestForm.get('manager').value.map(manager => manager.empId)
    }

    console.log(payload);
    this.leaveService.submitRequest(payload).subscribe(response => {
      var email = "";
      for(var manager of this.requestForm.get('manager').value){
        email =  email + `${manager.email};`; 
      }
      var subject = "Action Required - Leave request submitted!"
      var body = `Hi,<br><br>
                  A leave request has been submitted by ${this.user.email} (Employee ID: ${this.user.empid}). The details are listed below:<br><br>
                  Start Date: ${this.datePipe.transform(this.requestForm.get('startDate').value, "yyyy-MM-dd")}<br>
                  End Date: ${this.datePipe.transform(this.requestForm.get('endDate').value, "yyyy-MM-dd")}<br>
                  Type of Leave: ${this.requestForm.get('type').value.name}<br>
                  Days: ${days}<br><br>
                  
                  Please respond to the request with a suitable action. Use the following <a href="${encodeURI("www.syncme.io/#/auth/login")}">link</a> to login into the portal.
                  <br><br>
                  Regards,<br>
                  Synceme Team.`;
      console.log(body);
      this.leaveService.sendEmail(email, subject, body).subscribe(emailRes => {
        this.status = `Succesfully submitted your details! The leave has been applied for ${this.days} days`;
        this.stepper.next();
      },
        emailErr => {
          this.status = "Request filed, but couldn't send notification to manager!";
          this.stepper.next();
        })
    },
      error => {
        this.status = "Error Occurred, please try again after some time";
        this.stepper.next();
      })
  }

  isSubmitActive() {
    return this.requestForm.invalid === false;
  }

  reset() {
    this.mangerList.reset();
    this.startTimeList.reset();
    this.endTimeList.reset();
    this.typeList.reset();
    this.requestForm.reset();
  }

  home() {
    this.router.navigate(['/pages/attendance/attendance-overview'])
  }
}
