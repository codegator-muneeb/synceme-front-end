import { Component } from '@angular/core';

@Component({
  selector: 'ngx-finish',
  templateUrl: './finish.component.html',
  styleUrls: ['./finish.component.scss']
})
export class FinishComponent {

}
