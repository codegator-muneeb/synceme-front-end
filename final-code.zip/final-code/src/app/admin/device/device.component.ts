import { Component } from '@angular/core';

@Component({
  selector: 'ngx-device',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class DeviceComponent {

}
