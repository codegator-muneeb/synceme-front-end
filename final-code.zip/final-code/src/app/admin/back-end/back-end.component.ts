import { Component } from '@angular/core';

@Component({
  selector: 'ngx-back-end',
  template: `
    <router-outlet></router-outlet>
  `,
})

export class BackEndComponent{

  constructor() { }

}
