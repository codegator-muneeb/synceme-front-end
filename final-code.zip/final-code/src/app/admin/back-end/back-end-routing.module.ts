import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BackEndComponent } from './back-end.component';
import { AssignManagerComponent } from './assign-manager/assign-manager.component';
import { RemoveManagerComponent } from './remove-manager/remove-manager.component';

const routes: Routes = [{
  path: '',
  component: BackEndComponent,
  children: [{
    path: 'assign-manager',
    component: AssignManagerComponent,
  },
  {
    path: 'remove-manager',
    component: RemoveManagerComponent,
  },
],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BackEndRoutingModule { }
