import { Component, OnInit, ViewChild } from '@angular/core';
import { NbAuthService, NbAuthJWTToken } from '@nebular/auth';
import { UserService } from '../../../services/user-service/user.service';
import { NbToastrService, NbGlobalPhysicalPosition } from '@nebular/theme';
import { user } from '../../../services/user-service/user-service.adapters';
import { NbToastStatus } from '@nebular/theme/components/toastr/model';

@Component({
  selector: 'ngx-remove-manager',
  templateUrl: './remove-manager.component.html',
  styleUrls: ['./remove-manager.component.scss']
})
export class RemoveManagerComponent {

  @ViewChild("managerList") mangerList: any;
  @ViewChild("empList") empList: any;

  user;

  listEnabled = false;
  listOfManagers = [];
  listOfEmployees = [];
  selectedManager: user
  selectedEmps = [];

  constructor(private authService: NbAuthService,
    private userService: UserService,
    private toastrService: NbToastrService) {
    this.authService.onTokenChange()
      .subscribe((token: NbAuthJWTToken) => {
        if (token.isValid()) {
          this.user = token.getPayload();
        }
      });

    this.userService.getAllUsers(this.user.companyCode)
      .subscribe(response => {
        this.listOfManagers = response;
      })
  }

  loadEmployees() {
    this.empList.reset();
    this.selectedEmps = [];
    this.userService.getTeamUsers(this.user.companyCode, this.selectedManager.empId).subscribe(response => {
      this.listOfEmployees = response;
      if (this.listOfEmployees.length !== 0) {
        this.listEnabled = true;
      }
    },
      error => {
        this.listOfEmployees = [];
        this.showToast(NbToastStatus.INFO, "Error", "Unabled to load employees!");
      })
  }

  isRemoveEnabled() {
    return this.selectedEmps.length !== 0 && typeof this.selectedManager !== "undefined";
  }

  removeManager() {
    var listofEmpIds = this.selectedEmps.map(emp => emp.empId);

    this.userService.removeManager(this.user.companyCode, this.selectedManager.empId, listofEmpIds).subscribe(res => {
      this.showToast(NbToastStatus.SUCCESS, "Success", "Operation successful!");
      this.reset();
    },
      err => {
        this.showToast(NbToastStatus.DANGER, "Error", "Operation failed!");
      })
  }

  private showToast(type: NbToastStatus, title: string, body: string) {
    const config = {
      status: type,
      destroyByClick: true,
      duration: 2000,
      hasIcon: true,
      position: NbGlobalPhysicalPosition.TOP_RIGHT,
      preventDuplicates: false,
    };
    const titleContent = title ? title : '';

    this.toastrService.show(
      body,
      titleContent,
      config);
  }

  reset() {
    this.mangerList.reset();
    this.selectedEmps = [];
  }

}
